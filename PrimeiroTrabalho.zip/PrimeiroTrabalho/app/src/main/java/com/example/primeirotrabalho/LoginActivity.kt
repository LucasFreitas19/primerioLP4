package com.example.primeirotrabalho

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_splash.view.*

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)


    }




    fun formValida(view: View){

        val user = findViewById<View>(R.id.editTextTextPersonName)
        val pass = findViewById<View>(R.id.editTextTextPassword)

        if (user.textView.text == "admin" && pass.textView.text == "pass"){
            var intent = Intent(applicationContext, MainActivity::class.java)
            startActivity(intent)

        } else {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show()
        }


    }
}